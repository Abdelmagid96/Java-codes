This is similar to the previous assignment in terms of the interactive session but there are new features such as add, load from file
and reset. The structure is different in terms of the data types because now it is mostly using linked lists. there are 3 classes main classes
with getters and setters and constructor. there's also  class for each of those with their data types such Courselist or StudentList.
Then there are Database classes which contain methods manipulating the data within the lists. An object of each of those classes is in the university
database which contains the primary methods to be used in the interactive session in the main class. The assignment2 class contains the
main and the interactive session using a University database object.