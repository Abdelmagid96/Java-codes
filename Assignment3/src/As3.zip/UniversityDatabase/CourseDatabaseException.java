//Abdul Siddig
package UniversityDatabase;

// Runtime exception for the CourseDatabase class.
class CourseDatabaseException extends java.lang.RuntimeException {
   
   public CourseDatabaseException( String s ) { super(s); }
   
}


