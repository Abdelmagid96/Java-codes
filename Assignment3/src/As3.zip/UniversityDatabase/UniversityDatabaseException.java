//Abdul Siddig


package UniversityDatabase;

// Runtime exception for the UniversityDatabase class.
public class UniversityDatabaseException extends java.lang.RuntimeException {
   
   public UniversityDatabaseException( String s ) { super(s); }
   
}


