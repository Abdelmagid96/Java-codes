//Abdul Siddig


package UniversityDatabase;

// Runtime exception for the StudentDatabase class.
class StudentDatabaseException extends java.lang.RuntimeException {
   
   public StudentDatabaseException( String s ) { super(s); }
   
}


